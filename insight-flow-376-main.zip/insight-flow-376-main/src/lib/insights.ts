import { startOfMonth, endOfMonth, subMonths, isWithinInterval, format, differenceInDays } from "date-fns";
import type { Expense, Category } from "./expense-store";
import { categoryConfig } from "./expense-store";

export interface Insight {
  type: "warning" | "info" | "success";
  emoji: string;
  message: string;
}

export function getMonthExpenses(expenses: Expense[], date: Date): Expense[] {
  const start = startOfMonth(date);
  const end = endOfMonth(date);
  return expenses.filter((e) =>
    isWithinInterval(new Date(e.date), { start, end })
  );
}

export function getTotalSpent(expenses: Expense[]): number {
  return expenses.reduce((sum, e) => sum + e.amount, 0);
}

export function getCategoryTotals(expenses: Expense[]) {
  const totals: Partial<Record<Category, number>> = {};
  for (const e of expenses) {
    totals[e.category] = (totals[e.category] || 0) + e.amount;
  }
  return Object.entries(totals)
    .map(([category, amount]) => ({
      category: category as Category,
      amount: amount!,
      ...categoryConfig[category as Category],
    }))
    .sort((a, b) => b.amount - a.amount);
}

export function getMonthlyTrend(expenses: Expense[]) {
  const now = new Date();
  const months: { month: string; total: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = subMonths(now, i);
    const monthExpenses = getMonthExpenses(expenses, d);
    months.push({
      month: format(d, "MMM"),
      total: getTotalSpent(monthExpenses),
    });
  }
  return months;
}

export function generateInsights(
  expenses: Expense[],
  budget: number
): Insight[] {
  const now = new Date();
  const thisMonthExpenses = getMonthExpenses(expenses, now);
  const lastMonthExpenses = getMonthExpenses(expenses, subMonths(now, 1));
  const thisTotal = getTotalSpent(thisMonthExpenses);
  const lastTotal = getTotalSpent(lastMonthExpenses);
  const insights: Insight[] = [];

  // Budget alerts
  const budgetPercent = (thisTotal / budget) * 100;
  if (budgetPercent >= 100) {
    insights.push({
      type: "warning",
      emoji: "🚨",
      message: `You've exceeded your ₹${budget.toLocaleString()} budget by ₹${(thisTotal - budget).toLocaleString()}!`,
    });
  } else if (budgetPercent >= 80) {
    insights.push({
      type: "warning",
      emoji: "⚠️",
      message: `You've used ${Math.round(budgetPercent)}% of your budget. ₹${(budget - thisTotal).toLocaleString()} remaining.`,
    });
  } else {
    insights.push({
      type: "success",
      emoji: "✅",
      message: `You're on track! ₹${(budget - thisTotal).toLocaleString()} remaining this month.`,
    });
  }

  // Month comparison
  if (lastTotal > 0) {
    const diff = thisTotal - lastTotal;
    const pct = Math.round(Math.abs((diff / lastTotal) * 100));
    if (diff > 0) {
      insights.push({
        type: "info",
        emoji: "📈",
        message: `You spent ${pct}% more this month compared to last month.`,
      });
    } else if (diff < 0) {
      insights.push({
        type: "success",
        emoji: "📉",
        message: `Great job! You spent ${pct}% less than last month.`,
      });
    }
  }

  // Top category
  const categoryTotals = getCategoryTotals(thisMonthExpenses);
  if (categoryTotals.length > 0) {
    const top = categoryTotals[0];
    insights.push({
      type: "info",
      emoji: top.emoji,
      message: `${top.label} is your highest expense category at ₹${top.amount.toLocaleString()}.`,
    });
  }

  // Daily average
  const daysElapsed = differenceInDays(now, startOfMonth(now)) + 1;
  const dailyAvg = Math.round(thisTotal / daysElapsed);
  insights.push({
    type: "info",
    emoji: "📊",
    message: `Your daily average spending is ₹${dailyAvg.toLocaleString()}.`,
  });

  return insights;
}
