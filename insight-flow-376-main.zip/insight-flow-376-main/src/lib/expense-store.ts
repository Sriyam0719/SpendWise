import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Category =
  | "food"
  | "travel"
  | "entertainment"
  | "shopping"
  | "bills"
  | "education"
  | "health"
  | "other";

export interface Expense {
  id: string;
  amount: number;
  category: Category;
  description: string;
  date: string; // ISO string
}

export interface BudgetState {
  monthlyBudget: number;
  expenses: Expense[];
  addExpense: (expense: Omit<Expense, "id">) => void;
  editExpense: (id: string, expense: Partial<Omit<Expense, "id">>) => void;
  deleteExpense: (id: string) => void;
  setBudget: (amount: number) => void;
}

export const categoryConfig: Record<
  Category,
  { label: string; color: string; emoji: string }
> = {
  food: { label: "Food & Dining", color: "#34d399", emoji: "🍔" },
  travel: { label: "Travel", color: "#60a5fa", emoji: "✈️" },
  entertainment: { label: "Entertainment", color: "#a78bfa", emoji: "🎬" },
  shopping: { label: "Shopping", color: "#f472b6", emoji: "🛍️" },
  bills: { label: "Bills & Utilities", color: "#fbbf24", emoji: "💡" },
  education: { label: "Education", color: "#2dd4bf", emoji: "📚" },
  health: { label: "Health", color: "#fb923c", emoji: "💊" },
  other: { label: "Other", color: "#94a3b8", emoji: "📦" },
};

const generateId = () => Math.random().toString(36).substring(2, 10);

// Seed data for demo
const now = new Date();
const thisMonth = now.getMonth();
const thisYear = now.getFullYear();
const lastMonth = thisMonth === 0 ? 11 : thisMonth - 1;
const lastMonthYear = thisMonth === 0 ? thisYear - 1 : thisYear;

const seedExpenses: Expense[] = [
  { id: generateId(), amount: 250, category: "food", description: "Groceries", date: new Date(thisYear, thisMonth, 2).toISOString() },
  { id: generateId(), amount: 45, category: "food", description: "Coffee & snacks", date: new Date(thisYear, thisMonth, 5).toISOString() },
  { id: generateId(), amount: 120, category: "travel", description: "Uber rides", date: new Date(thisYear, thisMonth, 3).toISOString() },
  { id: generateId(), amount: 500, category: "bills", description: "Phone & Internet", date: new Date(thisYear, thisMonth, 1).toISOString() },
  { id: generateId(), amount: 200, category: "entertainment", description: "Netflix & Spotify", date: new Date(thisYear, thisMonth, 4).toISOString() },
  { id: generateId(), amount: 350, category: "shopping", description: "New headphones", date: new Date(thisYear, thisMonth, 6).toISOString() },
  { id: generateId(), amount: 80, category: "education", description: "Online course", date: new Date(thisYear, thisMonth, 7).toISOString() },
  { id: generateId(), amount: 150, category: "health", description: "Gym membership", date: new Date(thisYear, thisMonth, 1).toISOString() },
  { id: generateId(), amount: 60, category: "food", description: "Dinner out", date: new Date(thisYear, thisMonth, 8).toISOString() },
  // Last month
  { id: generateId(), amount: 180, category: "food", description: "Groceries", date: new Date(lastMonthYear, lastMonth, 5).toISOString() },
  { id: generateId(), amount: 300, category: "shopping", description: "Clothes", date: new Date(lastMonthYear, lastMonth, 10).toISOString() },
  { id: generateId(), amount: 90, category: "travel", description: "Bus pass", date: new Date(lastMonthYear, lastMonth, 1).toISOString() },
  { id: generateId(), amount: 500, category: "bills", description: "Rent utilities", date: new Date(lastMonthYear, lastMonth, 1).toISOString() },
  { id: generateId(), amount: 60, category: "entertainment", description: "Movie tickets", date: new Date(lastMonthYear, lastMonth, 15).toISOString() },
  { id: generateId(), amount: 200, category: "education", description: "Books", date: new Date(lastMonthYear, lastMonth, 20).toISOString() },
];

export const useExpenseStore = create<BudgetState>()(
  persist(
    (set) => ({
      monthlyBudget: 5000,
      expenses: seedExpenses,
      addExpense: (expense) =>
        set((state) => ({
          expenses: [{ ...expense, id: generateId() }, ...state.expenses],
        })),
      editExpense: (id, updates) =>
        set((state) => ({
          expenses: state.expenses.map((e) =>
            e.id === id ? { ...e, ...updates } : e
          ),
        })),
      deleteExpense: (id) =>
        set((state) => ({
          expenses: state.expenses.filter((e) => e.id !== id),
        })),
      setBudget: (amount) => set({ monthlyBudget: amount }),
    }),
    { name: "expense-tracker-storage" }
  )
);
