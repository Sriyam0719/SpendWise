import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Plus } from "lucide-react";
import { useExpenseStore, categoryConfig, type Category } from "@/lib/expense-store";

interface Props {
  open: boolean;
  onClose: () => void;
  editExpense?: { id: string; amount: number; category: Category; description: string; date: string } | null;
}

export function AddExpenseDialog({ open, onClose, editExpense }: Props) {
  const { addExpense, editExpense: updateExpense } = useExpenseStore();
  const [amount, setAmount] = useState(editExpense?.amount?.toString() || "");
  const [category, setCategory] = useState<Category>(editExpense?.category || "food");
  const [description, setDescription] = useState(editExpense?.description || "");
  const [date, setDate] = useState(editExpense?.date ? new Date(editExpense.date).toISOString().split("T")[0] : new Date().toISOString().split("T")[0]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      amount: parseFloat(amount),
      category,
      description,
      date: new Date(date).toISOString(),
    };
    if (editExpense) {
      updateExpense(editExpense.id, data);
    } else {
      addExpense(data);
    }
    onClose();
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="glass-card w-full max-w-md rounded-2xl p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-display font-bold text-foreground">
                {editExpense ? "Edit Expense" : "Add Expense"}
              </h2>
              <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">Amount (₹)</label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0"
                  required
                  min="1"
                  className="w-full rounded-xl bg-input px-4 py-3 text-2xl font-bold text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-2 block">Category</label>
                <div className="grid grid-cols-4 gap-2">
                  {(Object.keys(categoryConfig) as Category[]).map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setCategory(cat)}
                      className={`flex flex-col items-center gap-1 rounded-xl p-2 text-xs transition-all ${
                        category === cat
                          ? "bg-primary/20 ring-2 ring-primary text-foreground"
                          : "bg-input text-muted-foreground hover:bg-accent"
                      }`}
                    >
                      <span className="text-lg">{categoryConfig[cat].emoji}</span>
                      <span className="truncate w-full text-center">{categoryConfig[cat].label.split(" ")[0]}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">Description</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="What was it for?"
                  required
                  className="w-full rounded-xl bg-input px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">Date</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full rounded-xl bg-input px-4 py-3 text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <button
                type="submit"
                className="w-full gradient-emerald rounded-xl py-3 font-semibold text-primary-foreground flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
              >
                <Plus size={18} />
                {editExpense ? "Save Changes" : "Add Expense"}
              </button>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
