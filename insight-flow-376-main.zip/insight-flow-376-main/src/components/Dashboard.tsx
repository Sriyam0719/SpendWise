import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import {
  PieChart, Pie, Cell, ResponsiveContainer,
  LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid,
} from "recharts";
import { Plus, Trash2, Pencil, Wallet, TrendingUp, Target, Lightbulb, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { useExpenseStore, categoryConfig, type Category, type Expense } from "@/lib/expense-store";
import { generateInsights, getMonthExpenses, getTotalSpent, getCategoryTotals, getMonthlyTrend } from "@/lib/insights";
import { AddExpenseDialog } from "./AddExpenseDialog";
import { format, subMonths } from "date-fns";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4 },
};

export function Dashboard() {
  const { expenses, monthlyBudget, deleteExpense, setBudget } = useExpenseStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [editingBudget, setEditingBudget] = useState(false);
  const [budgetInput, setBudgetInput] = useState(monthlyBudget.toString());

  const now = new Date();
  const thisMonthExpenses = useMemo(() => getMonthExpenses(expenses, now), [expenses]);
  const lastMonthExpenses = useMemo(() => getMonthExpenses(expenses, subMonths(now, 1)), [expenses]);
  const totalSpent = useMemo(() => getTotalSpent(thisMonthExpenses), [thisMonthExpenses]);
  const lastMonthTotal = useMemo(() => getTotalSpent(lastMonthExpenses), [lastMonthExpenses]);
  const categoryTotals = useMemo(() => getCategoryTotals(thisMonthExpenses), [thisMonthExpenses]);
  const monthlyTrend = useMemo(() => getMonthlyTrend(expenses), [expenses]);
  const insights = useMemo(() => generateInsights(expenses, monthlyBudget), [expenses, monthlyBudget]);

  const budgetPercent = Math.min((totalSpent / monthlyBudget) * 100, 100);
  const monthDiff = lastMonthTotal > 0 ? ((totalSpent - lastMonthTotal) / lastMonthTotal) * 100 : 0;

  const handleSaveBudget = () => {
    const val = parseFloat(budgetInput);
    if (val > 0) setBudget(val);
    setEditingBudget(false);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-md sticky top-0 z-40 bg-background/80">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl gradient-emerald flex items-center justify-center">
              <Wallet size={18} className="text-primary-foreground" />
            </div>
            <h1 className="text-xl font-display font-bold text-foreground">
              Spend<span className="text-gradient">Wise</span>
            </h1>
          </div>
          <button
            onClick={() => { setEditingExpense(null); setDialogOpen(true); }}
            className="gradient-emerald rounded-xl px-4 py-2 text-sm font-semibold text-primary-foreground flex items-center gap-2 hover:opacity-90 transition-opacity glow-emerald"
          >
            <Plus size={16} /> Add Expense
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6 space-y-6">
        {/* Stats Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <motion.div {...fadeUp} className="glass-card rounded-2xl p-5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">This Month</span>
              {monthDiff !== 0 && (
                <span className={`text-xs flex items-center gap-0.5 ${monthDiff > 0 ? "text-destructive" : "text-primary"}`}>
                  {monthDiff > 0 ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                  {Math.abs(Math.round(monthDiff))}%
                </span>
              )}
            </div>
            <p className="text-3xl font-display font-bold text-foreground">₹{totalSpent.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground mt-1">{format(now, "MMMM yyyy")}</p>
          </motion.div>

          <motion.div {...fadeUp} transition={{ delay: 0.1 }} className="glass-card rounded-2xl p-5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Budget</span>
              <button onClick={() => setEditingBudget(!editingBudget)} className="text-xs text-primary hover:underline">
                {editingBudget ? "Cancel" : "Edit"}
              </button>
            </div>
            {editingBudget ? (
              <div className="flex gap-2">
                <input
                  type="number"
                  value={budgetInput}
                  onChange={(e) => setBudgetInput(e.target.value)}
                  className="flex-1 bg-input rounded-lg px-3 py-1 text-foreground text-lg font-bold focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <button onClick={handleSaveBudget} className="gradient-emerald px-3 rounded-lg text-sm text-primary-foreground font-semibold">
                  Save
                </button>
              </div>
            ) : (
              <>
                <p className="text-3xl font-display font-bold text-foreground">₹{monthlyBudget.toLocaleString()}</p>
                <div className="mt-2 h-2 rounded-full bg-secondary overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${budgetPercent}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className={`h-full rounded-full ${budgetPercent >= 90 ? "bg-destructive" : budgetPercent >= 70 ? "bg-warning" : "bg-primary"}`}
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-1">{Math.round(budgetPercent)}% used</p>
              </>
            )}
          </motion.div>

          <motion.div {...fadeUp} transition={{ delay: 0.2 }} className="glass-card rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <Target size={14} className="text-primary" />
              <span className="text-sm text-muted-foreground">Remaining</span>
            </div>
            <p className={`text-3xl font-display font-bold ${monthlyBudget - totalSpent >= 0 ? "text-primary" : "text-destructive"}`}>
              ₹{Math.abs(monthlyBudget - totalSpent).toLocaleString()}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {monthlyBudget - totalSpent >= 0 ? "left to spend" : "over budget"}
            </p>
          </motion.div>
        </div>

        {/* Charts + Insights */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Pie Chart */}
          <motion.div {...fadeUp} transition={{ delay: 0.3 }} className="glass-card rounded-2xl p-5">
            <h3 className="font-display font-semibold text-foreground mb-4 flex items-center gap-2">
              <TrendingUp size={16} className="text-primary" /> By Category
            </h3>
            {categoryTotals.length > 0 ? (
              <>
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={categoryTotals} dataKey="amount" nameKey="label" cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3}>
                      {categoryTotals.map((entry) => (
                        <Cell key={entry.category} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{ background: "oklch(0.17 0.02 250)", border: "1px solid oklch(0.3 0.02 250 / 40%)", borderRadius: "12px", color: "#fff" }}
                      formatter={(value: any) => [`₹${Number(value).toLocaleString()}`, ""]}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="space-y-2 mt-3">
                  {categoryTotals.slice(0, 4).map((cat) => (
                    <div key={cat.category} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full" style={{ background: cat.color }} />
                        <span className="text-muted-foreground">{cat.label}</span>
                      </div>
                      <span className="font-medium text-foreground">₹{cat.amount.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-10">No expenses this month</p>
            )}
          </motion.div>

          {/* Line Chart */}
          <motion.div {...fadeUp} transition={{ delay: 0.4 }} className="glass-card rounded-2xl p-5 lg:col-span-2">
            <h3 className="font-display font-semibold text-foreground mb-4">Monthly Trend</h3>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={monthlyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.02 250 / 50%)" />
                <XAxis dataKey="month" stroke="oklch(0.6 0.02 250)" fontSize={12} />
                <YAxis stroke="oklch(0.6 0.02 250)" fontSize={12} tickFormatter={(v) => `₹${v}`} />
                <Tooltip
                  contentStyle={{ background: "oklch(0.17 0.02 250)", border: "1px solid oklch(0.3 0.02 250 / 40%)", borderRadius: "12px", color: "#fff" }}
                  formatter={(value: any) => [`₹${Number(value).toLocaleString()}`, "Total"]}
                />
                <Line type="monotone" dataKey="total" stroke="oklch(0.72 0.19 160)" strokeWidth={3} dot={{ fill: "oklch(0.72 0.19 160)", r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </motion.div>
        </div>

        {/* Smart Insights */}
        <motion.div {...fadeUp} transition={{ delay: 0.5 }} className="glass-card rounded-2xl p-5">
          <h3 className="font-display font-semibold text-foreground mb-4 flex items-center gap-2">
            <Lightbulb size={16} className="text-warning" /> Smart Insights
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {insights.map((insight, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 + i * 0.1 }}
                className={`rounded-xl p-4 text-sm flex items-start gap-3 ${
                  insight.type === "warning" ? "bg-destructive/10 border border-destructive/20" :
                  insight.type === "success" ? "bg-primary/10 border border-primary/20" :
                  "bg-accent border border-border/50"
                }`}
              >
                <span className="text-lg shrink-0">{insight.emoji}</span>
                <p className="text-surface-foreground">{insight.message}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Recent Expenses */}
        <motion.div {...fadeUp} transition={{ delay: 0.6 }} className="glass-card rounded-2xl p-5">
          <h3 className="font-display font-semibold text-foreground mb-4">Recent Expenses</h3>
          {thisMonthExpenses.length > 0 ? (
            <div className="space-y-2">
              {thisMonthExpenses
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .map((expense) => {
                  const cfg = categoryConfig[expense.category];
                  return (
                    <motion.div
                      key={expense.id}
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="flex items-center justify-between py-3 px-4 rounded-xl hover:bg-accent/50 transition-colors group"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{cfg.emoji}</span>
                        <div>
                          <p className="font-medium text-foreground text-sm">{expense.description}</p>
                          <p className="text-xs text-muted-foreground">{cfg.label} · {format(new Date(expense.date), "MMM d")}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-display font-bold text-foreground">₹{expense.amount.toLocaleString()}</span>
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => { setEditingExpense(expense); setDialogOpen(true); }}
                            className="p-1.5 rounded-lg hover:bg-primary/20 text-muted-foreground hover:text-primary transition-colors"
                          >
                            <Pencil size={14} />
                          </button>
                          <button
                            onClick={() => deleteExpense(expense.id)}
                            className="p-1.5 rounded-lg hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-colors"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-8">No expenses yet. Tap "Add Expense" to get started!</p>
          )}
        </motion.div>
      </main>

      <AddExpenseDialog
        open={dialogOpen}
        onClose={() => { setDialogOpen(false); setEditingExpense(null); }}
        editExpense={editingExpense}
      />
    </div>
  );
}
