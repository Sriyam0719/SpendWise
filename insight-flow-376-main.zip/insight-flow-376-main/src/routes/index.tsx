import { createFileRoute } from "@tanstack/react-router";
import { Dashboard } from "@/components/Dashboard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SpendWise — Smart Expense Tracker" },
      { name: "description", content: "Track your expenses, analyze spending habits, and get smart insights to manage your money better." },
      { property: "og:title", content: "SpendWise — Smart Expense Tracker" },
      { property: "og:description", content: "Track expenses, visualize spending, and get AI-powered financial insights." },
    ],
  }),
  component: Dashboard,
});
